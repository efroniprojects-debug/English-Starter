
import React from 'react';
import Card from './ui/Card';

interface GradesProps {
  onSelectGrade: (grade: number) => void;
}

const gradeColors = [
    "from-teal-300 to-cyan-400",
    "from-green-300 to-emerald-400",
    "from-yellow-300 to-amber-400",
    "from-orange-300 to-red-400",
    "from-indigo-300 to-purple-400",
    "from-sky-300 to-blue-400",
]

const Grades: React.FC<GradesProps> = ({ onSelectGrade }) => {
  return (
    <section>
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-10">בחירת כיתה</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
        {[...Array(6)].map((_, i) => (
          <Card key={i} onClick={() => onSelectGrade(i + 1)} className={`relative overflow-hidden aspect-video flex flex-col items-center justify-center text-center p-6 bg-gradient-to-br ${gradeColors[i]}`}>
             <div className="absolute -bottom-8 -right-8 text-white/10 text-9xl font-black">{['א', 'ב', 'ג', 'ד', 'ה', 'ו'][i]}</div>
            <div className="relative z-10">
                <div className="text-xl font-semibold text-white/90">כיתה</div>
                <div className="text-5xl font-bold text-white drop-shadow-lg">{['א', 'ב', 'ג', 'ד', 'ה', 'ו'][i]}</div>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
};

export default Grades;
