
import React from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import type { Page } from '../App';

interface HomeProps {
    onNavigate: (page: Page) => void;
    onSelectGrade: (grade: number) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate, onSelectGrade }) => {

  const features = [
    { title: "למידה מותאמת", description: "תוכן המותאם לתכנית הלימודים בישראל, מכיתה א' ועד ו'.", icon: <GraduationCapIcon /> },
    { title: "משחקים וכיף", description: "משחקי זיכרון, התאמה, איות ובינגו שהופכים את הלמידה לחוויה.", icon: <GameIcon /> },
    { title: "שיפור ההגייה", description: "תרגול דיבור עם משוב מיידי בעזרת טכנולוגיה מתקדמת.", icon: <MicIcon /> },
    { title: "מעקב התקדמות", description: "צפו בהתקדמות, צברו נקודות ושדרגו את האווטאר שלכם.", icon: <ChartIcon /> },
  ];

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center py-12">
        <h1 className="text-4xl md:text-6xl font-extrabold text-slate-800 mb-4">ללמוד אנגלית בכיף וביעילות</h1>
        <p className="text-lg md:text-xl text-slate-600 max-w-3xl mx-auto mb-8">
          פלטפורמת ABC English Explorer מציעה עולם שלם של תוכן, משחקים ופעילויות לחיזוק האנגלית, במיוחד לתלמידי בית הספר היסודי בישראל.
        </p>
        <Button onClick={() => onSelectGrade(1)} className="text-xl">
          התחילו ללמוד עכשיו!
        </Button>
      </section>

      {/* Features Section */}
      <section>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="p-6 text-center">
              <div className="mx-auto bg-blue-100 text-blue-500 rounded-full h-16 w-16 flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-slate-600">{feature.description}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* Grades Section Preview */}
      <section>
        <h2 className="text-3xl font-bold text-center mb-8">בחרו את הכיתה שלכם</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {[...Array(6)].map((_, i) => (
                <Card key={i} onClick={() => onSelectGrade(i + 1)} className="aspect-square flex flex-col items-center justify-center text-center p-4 bg-gradient-to-br from-amber-300 to-orange-400">
                    <div className="text-4xl font-bold text-white drop-shadow-lg">{['א', 'ב', 'ג', 'ד', 'ה', 'ו'][i]}</div>
                    <div className="text-lg font-semibold text-white/90">כיתה</div>
                </Card>
            ))}
        </div>
      </section>
    </div>
  );
};

// SVG Icons
const GraduationCapIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5"/></svg>;
const GameIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16.5 10.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zM12 12L7.5 7.5M12 12l4.5-4.5M12 12v9"/><path d="M12 2a10 10 0 1 0 10 10c0-4-3-8-5-9.5V2z"/></svg>;
const MicIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>;
const ChartIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="M18.7 8a6 6 0 0 0-6-6"/><path d="M13 13a6 6 0 0 0 6 6"/></svg>;

export default Home;
