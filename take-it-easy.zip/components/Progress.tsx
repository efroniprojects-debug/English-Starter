
import React from 'react';
import { useUser } from '../context/UserContext';
import Card from './ui/Card';

const Progress: React.FC = () => {
  const { progress, profile } = useUser();

  const stats = [
    { label: 'יחידות שהושלמו', value: progress.completedUnits.length, icon: '📚' },
    { label: 'מילים שנלמדו', value: progress.learnedWords.length, icon: '🔤' },
    { label: 'ניקוד ממוצע', value: `${progress.averageScore}%`, icon: '🎯' },
    { label: 'רצף למידה', value: `${progress.streak} ימים`, icon: '🔥' },
  ];

  return (
    <section>
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-10">ההתקדמות שלי</h1>
      
      <Card className="p-6 mb-10 max-w-md mx-auto flex items-center space-i-4 bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
        <img src={`/assets/images/avatar-${profile.avatarId}.png`} alt="User Avatar" className="h-20 w-20 rounded-full border-4 border-white/50 bg-white" onError={(e) => e.currentTarget.src = 'https://picsum.photos/80/80'} />
        <div>
            <h2 className="text-2xl font-bold">שלום, {profile.name}!</h2>
            <p className="opacity-80">כיף לראות אותך ממשיך/ה ללמוד</p>
        </div>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="p-6 text-center">
            <div className="text-4xl mb-3">{stat.icon}</div>
            <div className="text-3xl font-bold text-slate-800">{stat.value}</div>
            <div className="text-slate-500">{stat.label}</div>
          </Card>
        ))}
      </div>
    </section>
  );
};

export default Progress;
