import React, { useState } from 'react';
import type { Page } from '../App';
import { useUser } from '../context/UserContext';

interface HeaderProps {
  onNavigate: (page: Page) => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
    const { progress, profile } = useUser();
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const navLinks: { page: Page; label: string }[] = [
        { page: 'home', label: 'דף הבית' },
        { page: 'grades', label: 'כיתות' },
        { page: 'games', label: 'משחקים' },
        { page: 'pronunciation', label: 'קריינות' },
        { page: 'progress', label: 'התקדמות' },
        { page: 'profile', label: 'פרופיל' },
    ];
    
    return (
        <header className="bg-white/80 backdrop-blur-sm shadow-md sticky top-0 z-50">
            <div className="container mx-auto px-4">
                <div className="flex items-center justify-between h-20">
                    <div className="flex items-center space-x-4 cursor-pointer" onClick={() => onNavigate('home')}>
                        <img src="/assets/images/logo.jpg" alt="Take It Easy Logo" className="h-12 w-12 rounded-full object-cover"/>
                        <span className="text-xl font-bold text-blue-600 hidden sm:block">Take It Easy</span>
                    </div>
                    
                    <nav className="hidden md:flex items-center space-x-12">
                        {navLinks.map(link => (
                            <a key={link.page} href="#" onClick={(e) => { e.preventDefault(); onNavigate(link.page); }} className="text-slate-600 hover:text-blue-500 font-semibold transition-colors">
                                {link.label}
                            </a>
                        ))}
                    </nav>

                    <div className="flex items-center space-x-4">
                        <span className="text-slate-600 font-semibold hidden sm:block">שלום, {profile.name}!</span>
                        <div className="flex items-center space-x-2 bg-amber-100 text-amber-800 font-bold px-3 py-1.5 rounded-full">
                            <StarIcon />
                            <span>{progress.points}</span>
                        </div>
                        <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                            <MenuIcon />
                        </button>
                    </div>
                </div>
                {/* Mobile Menu */}
                {isMenuOpen && (
                    <div className="md:hidden pb-4">
                        <nav className="flex flex-col space-y-2">
                            {navLinks.map(link => (
                                <a key={link.page} href="#" onClick={(e) => { e.preventDefault(); onNavigate(link.page); setIsMenuOpen(false); }} className="text-slate-600 hover:text-blue-500 font-semibold transition-colors px-4 py-2 rounded-md hover:bg-sky-100">
                                    {link.label}
                                </a>
                            ))}
                        </nav>
                    </div>
                )}
            </div>
        </header>
    );
};

const StarIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
);
const MenuIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
);


export default Header;