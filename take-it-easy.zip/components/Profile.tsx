import React, { useState, useEffect } from 'react';
import { useUser } from '../context/UserContext';
import type { Avatar } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';

const Profile: React.FC = () => {
  const { profile, setProfile, progress, unlockAvatar } = useUser();
  const [userName, setUserName] = useState(profile.name);
  const [avatars, setAvatars] = useState<Avatar[]>([]);
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState('');

  useEffect(() => {
    fetch('/data/avatars.json')
      .then(res => res.json())
      .then(data => {
        setAvatars(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Failed to load avatars:", err);
        setLoading(false);
      });
  }, []);

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(''), 3000);
  };

  const handleSaveProfile = () => {
    setProfile({ ...profile, name: userName });
    showNotification('הפרופיל נשמר!');
  };

  const handleSelectAvatar = (avatarId: number) => {
    if (profile.unlockedAvatars.includes(avatarId)) {
      setProfile({ ...profile, avatarId: avatarId });
    }
  };

  const handleUnlockAvatar = (avatar: Avatar) => {
    if (unlockAvatar(avatar)) {
      showNotification(`'${avatar.name}' נפתח!`);
    } else {
      showNotification('אין לך מספיק נקודות!');
    }
  };

  if (loading) {
    return <div className="text-center p-10">טוען אוואטרים...</div>;
  }

  return (
    <section>
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-10">הפרופיל שלי</h1>
      
      {notification && (
        <div className="fixed top-24 right-1/2 translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
          {notification}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {/* Profile Card */}
        <Card className="lg:col-span-1 p-6 flex flex-col items-center text-center self-start">
          <img 
            src={`/assets/images/avatar-${profile.avatarId}.png`} 
            alt="Current Avatar" 
            className="h-32 w-32 rounded-full border-4 border-blue-300 bg-white mb-4"
            onError={(e) => e.currentTarget.src = 'https://picsum.photos/128/128'}
          />
          <div className="w-full">
            <label htmlFor="userName" className="font-semibold text-slate-700 block mb-2">שם משתמש</label>
            <input 
              id="userName"
              type="text" 
              value={userName} 
              onChange={(e) => setUserName(e.target.value)} 
              className="w-full p-2 border border-slate-300 rounded-md text-center focus:ring-blue-400 focus:border-blue-400"
            />
          </div>
          <Button onClick={handleSaveProfile} className="mt-4 w-full">שמור שינויים</Button>
          <div className="mt-6 border-t pt-4 w-full">
            <div className="flex items-center justify-center space-i-2 text-xl font-bold text-amber-600">
              <StarIcon />
              <span className="ms-1">{progress.points} נקודות</span>
            </div>
          </div>
        </Card>

        {/* Avatars Gallery */}
        <div className="lg:col-span-2">
          <h2 className="text-2xl font-bold mb-4">בחירת אוואטר</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {avatars.map(avatar => {
              const isUnlocked = profile.unlockedAvatars.includes(avatar.id);
              const isSelected = profile.avatarId === avatar.id;
              
              return (
                <Card key={avatar.id} className="p-4 text-center relative overflow-hidden flex flex-col justify-between">
                  <div>
                    <img 
                      src={avatar.image} 
                      alt={avatar.name} 
                      className={`h-24 w-24 rounded-full mx-auto mb-2 transition-all ${!isUnlocked ? 'filter grayscale opacity-60' : ''} ${isSelected ? 'border-4 border-green-400 p-1' : 'border-4 border-transparent'}`}
                      onError={(e) => e.currentTarget.src = 'https://picsum.photos/96/96'}
                    />
                    <h3 className="font-semibold text-slate-800 h-12 flex items-center justify-center">{avatar.name}</h3>
                  </div>
                  
                  <div className="mt-2">
                  {!isUnlocked ? (
                      <Button variant="secondary" onClick={() => handleUnlockAvatar(avatar)} disabled={progress.points < avatar.cost}>
                        <div className="flex items-center justify-center text-sm">
                          <StarIcon />
                          <span className="ms-1">{avatar.cost}</span>
                        </div>
                      </Button>
                    ) : (
                      <Button onClick={() => handleSelectAvatar(avatar.id)} disabled={isSelected} variant={isSelected ? 'primary' : 'secondary'}>
                        {isSelected ? 'נבחר' : 'בחר'}
                      </Button>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

const StarIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
);

export default Profile;