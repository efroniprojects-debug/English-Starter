import React, { useState, useEffect } from 'react';
import type { MatchingLevel, MatchingItem } from '../../types';
import { useUser } from '../../context/UserContext';
import Button from '../ui/Button';

interface MatchingGameProps {
  levels: MatchingLevel[];
}

const MatchingGame: React.FC<MatchingGameProps> = ({ levels }) => {
  const [currentLevel, setCurrentLevel] = useState(0);
  const [items, setItems] = useState<MatchingItem[]>([]);
  const [shuffledDefinitions, setShuffledDefinitions] = useState<string[]>([]);
  const [selectedTerm, setSelectedTerm] = useState<MatchingItem | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<string[]>([]);
  const [incorrectSelection, setIncorrectSelection] = useState<string | null>(null);
  const { addPoints } = useUser();

  useEffect(() => {
    setupLevel(currentLevel);
  }, [currentLevel, levels]);

  const setupLevel = (levelIndex: number) => {
    const levelData = levels[levelIndex];
    if (!levelData) return;
    
    setItems(levelData.items);
    setShuffledDefinitions(
      [...levelData.items].map(i => i.definition).sort(() => Math.random() - 0.5)
    );
    setSelectedTerm(null);
    setMatchedPairs([]);
    setIncorrectSelection(null);
  };
  
  const handleTermClick = (term: MatchingItem) => {
      if(matchedPairs.includes(term.term)) return;
      setSelectedTerm(term);
      setIncorrectSelection(null);
  }

  const handleDefinitionClick = (definition: string) => {
      if(!selectedTerm) return;

      if(selectedTerm.definition === definition) {
          setMatchedPairs([...matchedPairs, selectedTerm.term]);
          setSelectedTerm(null);
      } else {
          setIncorrectSelection(definition);
          setTimeout(() => setIncorrectSelection(null), 800);
      }
  }
  
  const allMatched = items.length > 0 && matchedPairs.length === items.length;

  const goToNextLevel = () => {
      if (currentLevel < levels.length - 1) {
          addPoints(10);
          setCurrentLevel(prev => prev + 1);
      }
  }

  const restartGame = () => {
    setCurrentLevel(0);
    setupLevel(0);
  }

  if (!levels || levels.length === 0) {
    return <p>לא נמצאו שלבים למשחק זה.</p>
  }

  if (currentLevel >= levels.length) {
     return (
        <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-green-600">כל הכבוד! סיימתם את כל השלבים! 🎉</h2>
            <Button onClick={restartGame}>שחקו שוב</Button>
        </div>
    );
  }
  
  return (
    <div className="flex flex-col items-center">
        <div className="w-full flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold">שלב: {currentLevel + 1} / {levels.length}</h3>
            <p className="text-lg font-semibold">{levels[currentLevel].title}</p>
        </div>
        
        <div className="w-full grid grid-cols-2 gap-4">
            {/* Terms Column */}
            <div className="space-y-3">
                {items.map(item => {
                    const isMatched = matchedPairs.includes(item.term);
                    const isSelected = selectedTerm?.term === item.term;
                    
                    let bgClass = 'bg-white hover:bg-sky-50';
                    if (isSelected) bgClass = 'bg-blue-200 ring-2 ring-blue-500';
                    if (isMatched) bgClass = 'bg-green-200 text-slate-500';

                    return (
                        <button key={item.term} onClick={() => handleTermClick(item)} disabled={isMatched}
                         className={`w-full text-right p-4 rounded-lg shadow-sm border transition-all duration-200 ${bgClass}`}>
                            <span className="font-bold text-lg">{item.term}</span>
                        </button>
                    )
                })}
            </div>
            {/* Definitions Column */}
            <div className="space-y-3">
                 {shuffledDefinitions.map(def => {
                    const term = items.find(i => i.definition === def)?.term;
                    const isMatched = term ? matchedPairs.includes(term) : false;
                    const isIncorrect = incorrectSelection === def;

                    let bgClass = 'bg-white hover:bg-amber-50';
                    if (isIncorrect) bgClass = 'bg-red-300 animate-shake';
                    if (isMatched) bgClass = 'bg-green-200 text-slate-500';

                     return (
                        <button key={def} onClick={() => handleDefinitionClick(def)} disabled={isMatched}
                         className={`w-full text-right p-4 rounded-lg shadow-sm border transition-all duration-200 ${bgClass}`}>
                             <span className="font-semibold text-lg">{def}</span>
                        </button>
                    )
                 })}
            </div>
        </div>
        {allMatched && (
        <div className="mt-6 text-center">
          <h2 className="text-xl font-bold mb-2 text-green-500">הצלחתם!</h2>
          <Button onClick={goToNextLevel}>לשלב הבא &rarr;</Button>
        </div>
      )}
    </div>
  )

};

export default MatchingGame;
