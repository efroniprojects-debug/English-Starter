import React, { useState, useEffect, useCallback } from 'react';
import type { BingoLevel } from '../../types';
import { useUser } from '../../context/UserContext';
import Button from '../ui/Button';

interface BingoGameProps {
  levels: BingoLevel[];
}

type BoardCell = {
  word: string;
  marked: boolean;
};

const BOARD_SIZE = 5;

const BingoGame: React.FC<BingoGameProps> = ({ levels }) => {
  const [currentLevel, setCurrentLevel] = useState(0);
  const [board, setBoard] = useState<(BoardCell | null)[][]>([]);
  const [availableWords, setAvailableWords] = useState<string[]>([]);
  const [calledWord, setCalledWord] = useState<string | null>(null);
  const [isWinner, setIsWinner] = useState(false);
  const { addPoints } = useUser();

  const generateBoard = useCallback((words: string[]) => {
    const shuffled = [...words].sort(() => 0.5 - Math.random());
    const newBoard: (BoardCell | null)[][] = Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(null));
    let wordIndex = 0;
    for (let i = 0; i < BOARD_SIZE; i++) {
      for (let j = 0; j < BOARD_SIZE; j++) {
        if (i === 2 && j === 2) {
            newBoard[i][j] = null; // Free space
        } else {
            newBoard[i][j] = { word: shuffled[wordIndex++], marked: false };
        }
      }
    }
    return newBoard;
  }, []);

  const setupLevel = useCallback((levelIndex: number) => {
    const levelData = levels[levelIndex];
    if (!levelData) return;

    setBoard(generateBoard(levelData.words));
    setAvailableWords([...levelData.words].sort(() => 0.5 - Math.random()));
    setCalledWord(null);
    setIsWinner(false);
  }, [levels, generateBoard]);

  useEffect(() => {
    setupLevel(currentLevel);
  }, [currentLevel, setupLevel]);

  const checkWinner = (currentBoard: (BoardCell | null)[][]) => {
    // Check rows and columns
    for (let i = 0; i < BOARD_SIZE; i++) {
      let rowWin = true;
      let colWin = true;
      for (let j = 0; j < BOARD_SIZE; j++) {
        // Row check
        if (i === 2 && j === 2) { // Free space
             if (!currentBoard[i][j]?.marked && !(i === 2 && j === 2)) rowWin = false;
        } else if (!currentBoard[i][j]?.marked) {
            rowWin = false;
        }
        // Col check
         if (i === 2 && j === 2) { // Free space
             if (!currentBoard[j][i]?.marked && !(j === 2 && i === 2)) colWin = false;
        } else if (!currentBoard[j][i]?.marked) {
            colWin = false;
        }
      }
      if (rowWin || colWin) return true;
    }

    // Check diagonals
    let diag1Win = true;
    let diag2Win = true;
    for (let i = 0; i < BOARD_SIZE; i++) {
        if (i === 2) { // Free space
             if (!board[i][i]?.marked && i !== 2) diag1Win = false;
             if (!board[i][BOARD_SIZE - 1 - i]?.marked && i !== 2) diag2Win = false;
        }
        else {
            if (!board[i][i]?.marked) diag1Win = false;
            if (!board[i][BOARD_SIZE - 1 - i]?.marked) diag2Win = false;
        }
    }
    if (diag1Win || diag2Win) return true;

    return false;
  };
  
  const handleCellClick = (row: number, col: number) => {
    if (isWinner) return;
    const cell = board[row][col];
    if (cell && cell.word === calledWord && !cell.marked) {
      const newBoard = board.map(r => r.map(c => c ? {...c} : null));
      newBoard[row][col]!.marked = true;
      setBoard(newBoard);
      if (checkWinner(newBoard)) {
        setIsWinner(true);
        addPoints(20);
      }
    }
  };

  const callNextWord = () => {
    if (availableWords.length > 0) {
      const nextWord = availableWords[0];
      setCalledWord(nextWord);
      setAvailableWords(availableWords.slice(1));
       if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(nextWord);
            utterance.lang = 'en-US';
            window.speechSynthesis.speak(utterance);
        }
    }
  };
  
  const goToNextLevel = () => {
      if (currentLevel < levels.length - 1) {
          setCurrentLevel(prev => prev + 1);
      }
  };

  const restartGame = () => {
      setCurrentLevel(0);
  }

  if (!levels || levels.length === 0) {
    return <p>לא נמצאו שלבים למשחק זה.</p>;
  }

  if (currentLevel >= levels.length && !isWinner) {
     return (
        <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-green-600">כל הכבוד! סיימתם את כל השלבים! 🎉</h2>
            <Button onClick={restartGame}>שחקו שוב</Button>
        </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      <div className="w-full flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold">שלב: {currentLevel + 1} / {levels.length}</h3>
      </div>
      
       <div className="h-20 w-full mb-4 flex items-center justify-center bg-sky-100 rounded-lg">
        {calledWord ? (
            <p className="text-3xl font-bold text-sky-800">{calledWord}</p>
        ) : (
            <p className="text-xl text-slate-500">לחצו "הכרז מילה" כדי להתחיל</p>
        )}
       </div>

      <div className="grid grid-cols-5 gap-2 mb-4">
        {board.map((row, rowIndex) =>
          row.map((cell, colIndex) => (
            <button
              key={`${rowIndex}-${colIndex}`}
              onClick={() => handleCellClick(rowIndex, colIndex)}
              className={`aspect-square w-20 h-20 sm:w-24 sm:h-24 flex items-center justify-center p-1 text-center font-bold rounded-md transition-all
                ${cell === null ? 'bg-amber-400 text-amber-800' : 'bg-white border-2'}
                ${cell?.marked ? 'bg-green-400 border-green-600 text-white transform scale-105' : 'border-slate-300'}
                ${cell?.word === calledWord && !cell.marked ? 'animate-pulse border-blue-500' : ''}
              `}
              disabled={isWinner || cell?.marked}
            >
              {cell === null ? 'FREE' : cell.word}
            </button>
          ))
        )}
      </div>

       {isWinner ? (
         <div className="text-center">
            <h2 className="text-3xl font-bold my-4 text-green-600 animate-bounce">🎉 BINGO! 🎉</h2>
             {currentLevel < levels.length - 1 ? (
                <Button onClick={goToNextLevel}>לשלב הבא &rarr;</Button>
             ) : (
                <Button onClick={restartGame}>שחקו שוב</Button>
             )}
         </div>
       ) : (
        <Button onClick={callNextWord} disabled={availableWords.length === 0}>
          {calledWord ? "הכרז מילה הבאה" : "הכרז מילה"}
        </Button>
       )}
    </div>
  );
};

export default BingoGame;