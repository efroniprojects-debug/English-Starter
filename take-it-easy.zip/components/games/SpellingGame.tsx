import React, { useState, useEffect } from 'react';
import type { SpellingWord } from '../../types';
import { useUser } from '../../context/UserContext';
import Button from '../ui/Button';

interface SpellingGameProps {
  words: SpellingWord[];
}

const keys = [
    'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p',
    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l',
    'z', 'x', 'c', 'v', 'b', 'n', 'm'
];

const SpellingGame: React.FC<SpellingGameProps> = ({ words }) => {
  const [currentLevel, setCurrentLevel] = useState(0);
  const [currentWord, setCurrentWord] = useState<SpellingWord | null>(null);
  const [userInput, setUserInput] = useState('');
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);
  const { addPoints } = useUser();

  useEffect(() => {
    setCurrentWord(words[currentLevel]);
    setUserInput('');
    setFeedback(null);
  }, [currentLevel, words]);

  const handleKeyPress = (key: string) => {
    if (feedback) return;
    setUserInput(prev => prev + key);
  };
  
  const handleDelete = () => {
    if (feedback) return;
    setUserInput(prev => prev.slice(0, -1));
  }

  const checkAnswer = () => {
    if (!currentWord) return;
    if (userInput.toLowerCase() === currentWord.word.toLowerCase()) {
      setFeedback('correct');
      addPoints(5);
      setTimeout(() => {
          if (currentLevel < words.length - 1) {
              setCurrentLevel(prev => prev + 1);
          }
      }, 1500);
    } else {
      setFeedback('incorrect');
      setTimeout(() => {
          setFeedback(null);
          setUserInput('');
      }, 1500);
    }
  };
  
  const restartGame = () => {
      setCurrentLevel(0);
  }
  
  if (!words || words.length === 0) {
    return <p>לא נמצאו שלבים למשחק זה.</p>
  }
  
  if (currentLevel >= words.length) {
      return (
          <div className="text-center">
              <h2 className="text-2xl font-bold mb-4 text-green-600">כל הכבוד! סיימתם את כל המילים! 🎉</h2>
              <Button onClick={restartGame}>שחקו שוב</Button>
          </div>
      );
  }

  if (!currentWord) return null;

  let inputBgClass = "bg-white";
  if(feedback === 'correct') inputBgClass = "bg-green-200 border-green-400";
  if(feedback === 'incorrect') inputBgClass = "bg-red-200 border-red-400 animate-shake";


  return (
    <div className="flex flex-col items-center">
        <div className="w-full flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold">מילה: {currentLevel + 1} / {words.length}</h3>
        </div>

        <div className="w-full max-w-md mx-auto text-center mb-6">
            <p className="text-slate-600 text-lg mb-2">אייתו את המילה שאתם שומעים. רמז: <span className="font-semibold">{currentWord.hint}</span></p>
            <Button variant="secondary" onClick={() => {
                const utterance = new SpeechSynthesisUtterance(currentWord.word);
                utterance.lang = 'en-US';
                window.speechSynthesis.speak(utterance);
            }}>
                שמעו שוב 🔊
            </Button>
        </div>

        <div className={`w-full max-w-md p-4 border-2 rounded-lg text-center text-3xl font-bold tracking-widest h-20 mb-6 transition-colors ${inputBgClass}`}>
            {userInput}
        </div>
        
        <div dir="ltr" className="w-full max-w-lg flex flex-wrap justify-center gap-2 mb-4">
            {keys.map(key => (
                <button key={key} onClick={() => handleKeyPress(key)}
                 className="h-12 w-12 bg-slate-200 hover:bg-slate-300 rounded-md font-bold text-xl transition-transform transform hover:scale-105">
                    {key.toUpperCase()}
                </button>
            ))}
        </div>
        <div className="flex space-x-4">
            <Button onClick={handleDelete}>מחק</Button>
            <Button onClick={checkAnswer} disabled={!userInput || feedback !== null}>בדוק</Button>
        </div>
    </div>
  )
};

export default SpellingGame;
