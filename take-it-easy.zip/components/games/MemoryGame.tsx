import React, { useState, useEffect } from 'react';
import type { MemoryLevel, MemoryPair } from '../../types';
import { useUser } from '../../context/UserContext';
import Card from '../ui/Card';
import Button from '../ui/Button';

interface MemoryGameProps {
  levels: MemoryLevel[];
}

interface CardState {
  id: number;
  content: string;
  type: 'en' | 'he';
  pairId: number;
  isFlipped: boolean;
  isMatched: boolean;
}

const MemoryGame: React.FC<MemoryGameProps> = ({ levels }) => {
  const [currentLevel, setCurrentLevel] = useState(0);
  const [cards, setCards] = useState<CardState[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [isChecking, setIsChecking] = useState(false);
  const { addPoints } = useUser();

  useEffect(() => {
    setupLevel(currentLevel);
  }, [currentLevel, levels]);

  const setupLevel = (levelIndex: number) => {
    const levelData = levels[levelIndex];
    if (!levelData) return;

    const newCards: CardState[] = [];
    levelData.pairs.forEach((pair, pairIndex) => {
      newCards.push({ id: newCards.length, content: pair.en, type: 'en', pairId: pairIndex, isFlipped: false, isMatched: false });
      newCards.push({ id: newCards.length, content: pair.he, type: 'he', pairId: pairIndex, isFlipped: false, isMatched: false });
    });

    // Shuffle cards
    for (let i = newCards.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newCards[i], newCards[j]] = [newCards[j], newCards[i]];
    }

    setCards(newCards);
    setFlippedIndices([]);
    setMoves(0);
  };

  const handleCardClick = (index: number) => {
    if (isChecking || cards[index].isFlipped || cards[index].isMatched || flippedIndices.length >= 2) {
      return;
    }

    const newFlippedIndices = [...flippedIndices, index];
    setFlippedIndices(newFlippedIndices);

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);

    if (newFlippedIndices.length === 2) {
      setMoves(moves + 1);
      checkMatch(newFlippedIndices);
    }
  };

  const checkMatch = (indices: number[]) => {
    setIsChecking(true);
    const [index1, index2] = indices;
    const card1 = cards[index1];
    const card2 = cards[index2];

    if (card1.pairId === card2.pairId) {
      setTimeout(() => {
        setCards(prevCards => prevCards.map((card, i) => 
          (i === index1 || i === index2) ? { ...card, isMatched: true } : card
        ));
        setFlippedIndices([]);
        setIsChecking(false);
      }, 800);
    } else {
      setTimeout(() => {
        setCards(prevCards => prevCards.map((card, i) => 
          (i === index1 || i === index2) ? { ...card, isFlipped: false } : card
        ));
        setFlippedIndices([]);
        setIsChecking(false);
      }, 1200);
    }
  };

  const allMatched = cards.length > 0 && cards.every(card => card.isMatched);

  const goToNextLevel = () => {
    if (currentLevel < levels.length - 1) {
      addPoints(10); // 10 points for completing a level
      setCurrentLevel(prev => prev + 1);
    }
  };

  const restartGame = () => {
    setCurrentLevel(0);
    setupLevel(0);
  }

  if (!levels || levels.length === 0) {
    return <p>לא נמצאו שלבים למשחק זה.</p>
  }

  if (currentLevel >= levels.length) {
     return (
        <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-green-600">כל הכבוד! סיימתם את כל השלבים! 🎉</h2>
            <Button onClick={restartGame}>שחקו שוב</Button>
        </div>
    );
  }

  const gridCols = levels[currentLevel].pairs.length <= 4 ? 'grid-cols-4' : 'grid-cols-4 lg:grid-cols-6';

  return (
    <div className="flex flex-col items-center">
      <div className="w-full flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold">שלב: {currentLevel + 1} / {levels.length}</h3>
        <p className="text-lg">מהלכים: {moves}</p>
      </div>
      <div className={`grid ${gridCols} gap-4 w-full`}>
        {cards.map((card, index) => (
          <div key={card.id} className="aspect-square" onClick={() => handleCardClick(index)}>
            <div className={`relative w-full h-full transition-transform duration-500 transform-style-preserve-3d ${card.isFlipped ? 'rotate-y-180' : ''}`}>
              {/* Card Back */}
              <div className="absolute w-full h-full backface-hidden flex items-center justify-center bg-blue-500 rounded-lg shadow-md cursor-pointer">
                <span className="text-4xl text-white font-bold">?</span>
              </div>
              {/* Card Front */}
              <div className={`absolute w-full h-full backface-hidden rotate-y-180 flex items-center justify-center rounded-lg shadow-lg ${card.isMatched ? 'bg-green-200' : 'bg-white'}`}>
                <span className={`text-center font-semibold text-lg p-1 ${card.type === 'he' ? 'text-blue-800' : 'text-slate-800'}`}>
                    {card.content}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
      {allMatched && (
        <div className="mt-6 text-center">
          <h2 className="text-xl font-bold mb-2 text-green-500">הצלחתם!</h2>
          <Button onClick={goToNextLevel}>לשלב הבא &rarr;</Button>
        </div>
      )}
    </div>
  );
};

export default MemoryGame;
