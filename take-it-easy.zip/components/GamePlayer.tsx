import React from 'react';
import type { ActiveGame } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';
import MemoryGame from './games/MemoryGame';
import MatchingGame from './games/MatchingGame';
import SpellingGame from './games/SpellingGame';
import BingoGame from './games/BingoGame';


interface GamePlayerProps {
    game: ActiveGame;
    onExit: () => void;
}

const GamePlayer: React.FC<GamePlayerProps> = ({ game, onExit }) => {

    const renderGame = () => {
        switch(game.type) {
            case 'memory':
                return <MemoryGame levels={game.data} />;
            case 'matching':
                return <MatchingGame levels={game.data} />;
            case 'spelling':
                return <SpellingGame words={game.data} />;
            case 'bingo':
                return <BingoGame levels={game.data} />;
            default:
                return <div>משחק לא ידוע</div>;
        }
    }

    const gameTitleMap = {
        'memory': 'משחק זיכרון',
        'matching': 'התאמת מילים',
        'spelling': 'איות נכון',
        'bingo': 'בינגו'
    };

    return (
        <section className="max-w-4xl mx-auto">
            <Card className="p-4 sm:p-6 bg-white/80 backdrop-blur-sm">
                <header className="flex justify-between items-center border-b pb-4 mb-6">
                    <div>
                        <h1 className="text-2xl sm:text-3xl font-bold text-blue-600">{gameTitleMap[game.type]}</h1>
                        <p className="text-slate-500">כיתה {game.grade} - {game.unitTitle}</p>
                    </div>
                    <Button onClick={onExit} variant="secondary">יציאה</Button>
                </header>
                <div className="game-content-area">
                    {renderGame()}
                </div>
            </Card>
        </section>
    );
};

export default GamePlayer;