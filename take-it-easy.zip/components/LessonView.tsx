import React, { useState, useEffect } from 'react';
import type { GradeData, Unit, ReadingPassage, ActiveGame } from '../types';
import { useUser } from '../context/UserContext';
import Card from './ui/Card';
import Button from './ui/Button';

interface LessonViewProps {
  grade: number;
  onLaunchGame: (game: ActiveGame) => void;
}

const LessonView: React.FC<LessonViewProps> = ({ grade, onLaunchGame }) => {
  const [gradeData, setGradeData] = useState<GradeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null);

  useEffect(() => {
    const fetchGradeData = async () => {
      try {
        setLoading(true);
        setError(null);
        setSelectedUnit(null);
        const response = await fetch(`/lessons/grade${grade}.json`);
        if (!response.ok) {
          throw new Error(`Could not load data for grade ${grade}`);
        }
        const data: GradeData = await response.json();
        setGradeData(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchGradeData();
  }, [grade]);

  if (loading) {
    return <div className="text-center p-10">טוען נתונים...</div>;
  }

  if (error) {
    return <div className="text-center p-10 text-red-500">שגיאה: {error}</div>;
  }

  if (!gradeData) {
    return null;
  }

  if (selectedUnit) {
    return <UnitView unit={selectedUnit} grade={grade} onBack={() => setSelectedUnit(null)} onLaunchGame={onLaunchGame} />;
  }
  
  return (
    <div>
      <h1 className="text-4xl font-bold text-center mb-2">{gradeData.title}</h1>
      <p className="text-center text-slate-500 mb-10">בחרו יחידת לימוד כדי להתחיל. כל יחידה מכילה אוצר מילים, משפטים, קטעי קריאה ומשחקים.</p>
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
        {gradeData.units.map((unit) => (
          <Card key={unit.unit} onClick={() => setSelectedUnit(unit)} className="p-4 text-center aspect-[4/5] flex flex-col justify-center">
            <div className="text-4xl font-bold text-blue-500 mb-2">{unit.unit}</div>
            <h3 className="font-semibold text-slate-800">{unit.title}</h3>
          </Card>
        ))}
      </div>
    </div>
  );
};

const FillInTheBlanksPassage: React.FC<{ passage: ReadingPassage }> = ({ passage }) => {
    const [answers, setAnswers] = useState<(string | null)[]>(() => Array(passage.blanks.length).fill(null));
    const [results, setResults] = useState<(boolean | null)[]>(() => Array(passage.blanks.length).fill(null));
    const [showTranslation, setShowTranslation] = useState(false);
    const [isComplete, setIsComplete] = useState(false);
    const { addPoints } = useUser();

    useEffect(() => {
        // Reset state when passage changes
        setAnswers(Array(passage.blanks.length).fill(null));
        setResults(Array(passage.blanks.length).fill(null));
        setShowTranslation(false);
        setIsComplete(false);
    }, [passage]);

    const handleSelectAnswer = (blankIndex: number, answer: string) => {
        setAnswers(prev => {
            const newAnswers = [...prev];
            newAnswers[blankIndex] = answer;
            return newAnswers;
        });
        setResults(Array(passage.blanks.length).fill(null));
        setIsComplete(false);
    };

    const checkAnswers = () => {
        let correctCount = 0;
        const newResults = passage.blanks.map((blank, index) => {
            const isCorrect = answers[index] === blank.correctAnswer;
            if(isCorrect) correctCount++;
            return isCorrect;
        });
        setResults(newResults);
        if(correctCount > 0) {
            addPoints(correctCount * 5);
        }
        setIsComplete(true);
    };
    
    const passageParts = passage.passageTemplate.split(/(__BLANK_\d+__)/g).filter(part => part !== "");
    
    return (
        <Card className="p-6">
            <div className="text-slate-700 text-lg leading-loose mb-6">
                {passageParts.map((part, index) => {
                    const match = part.match(/__BLANK_(\d+)__/);
                    if (match) {
                        const blankIndex = parseInt(match[1], 10);
                        const blank = passage.blanks[blankIndex];
                        
                        const baseClasses = "appearance-none inline-block font-semibold px-3 py-1 rounded-lg border-2 text-center bg-slate-100 ";
                        let colorClasses = "border-slate-300 text-slate-700";
                        if (results[blankIndex] === true) colorClasses = "border-green-400 bg-green-100 text-green-800";
                        if (results[blankIndex] === false) colorClasses = "border-red-400 bg-red-100 text-red-800";

                        return (
                            <select 
                                key={index}
                                value={answers[blankIndex] || ''}
                                onChange={(e) => handleSelectAnswer(blankIndex, e.target.value)}
                                className={`${baseClasses} ${colorClasses}`}
                            >
                                <option value="" disabled>בחר...</option>
                                {blank.options.map(option => (
                                    <option key={option} value={option}>{option}</option>
                                ))}
                            </select>
                        );
                    }
                    return <span key={index}>{part}</span>;
                })}
            </div>
             <div className="mt-4 flex flex-wrap gap-2 items-center">
                <Button onClick={checkAnswers} disabled={answers.includes(null)}>
                    בדוק תשובות
                </Button>
                <Button variant="secondary" onClick={() => setShowTranslation(!showTranslation)} className="py-2 px-4 text-sm">
                    {showTranslation ? 'הסתר תרגום' : 'הצג תרגום'}
                </Button>
                 {isComplete && results.every(r => r === true) && (
                    <span className="font-semibold text-green-600">כל הכבוד! כל התשובות נכונות! 🎉</span>
                )}
            </div>
            {showTranslation && (
                <p className="mt-4 p-3 bg-sky-50 rounded-lg text-slate-600 border border-sky-200">
                    {passage.translation}
                </p>
            )}
        </Card>
    );
};


const UnitView: React.FC<{ unit: Unit; grade: number; onBack: () => void; onLaunchGame: (game: ActiveGame) => void; }> = ({ unit, grade, onBack, onLaunchGame }) => {
    const [selectedPassageIndex, setSelectedPassageIndex] = useState(0);

    const speak = (text: string, lang: 'en-US' | 'he-IL' = 'en-US') => {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = lang;
            window.speechSynthesis.speak(utterance);
        } else {
            alert('מצטערים, הדפדפן שלך לא תומך בהקראת טקסט.');
        }
    };

    return (
        <div>
            <Button onClick={onBack} variant="secondary" className="mb-6">&larr; חזרה ליחידות</Button>
            <h2 className="text-3xl font-bold mb-1">יחידה {unit.unit}: {unit.title}</h2>
            
            <section className="mt-8">
                <h3 className="text-2xl font-semibold mb-4 border-b-2 border-blue-200 pb-2">אוצר מילים</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {unit.vocabulary.map((word, index) => (
                        <Card key={index} className="p-4 flex justify-between items-center">
                            <div>
                                <p className="text-xl font-bold text-slate-800">{word.en}</p>
                                <p className="text-md text-slate-500">{word.he}</p>
                            </div>
                            <button onClick={() => speak(word.en, 'en-US')} className="p-2 rounded-full hover:bg-sky-100 text-sky-500" aria-label={`Listen to ${word.en}`}>
                                <SoundIcon />
                            </button>
                        </Card>
                    ))}
                </div>
            </section>

            <section className="mt-8">
                <h3 className="text-2xl font-semibold mb-4 border-b-2 border-amber-200 pb-2">משפטים לדוגמה</h3>
                <div className="space-y-4">
                    {unit.sentences.map((sentence, index) => (
                         <Card key={index} className="p-4">
                            <div className="flex justify-between items-start">
                                <div>
                                    <p className="text-lg font-semibold text-slate-800 mb-1">{sentence.en}</p>
                                    <p className="text-md text-slate-500">{sentence.he}</p>
                                </div>
                                <button onClick={() => speak(sentence.en, 'en-US')} className="p-2 rounded-full hover:bg-sky-100 text-sky-500 flex-shrink-0 ms-4" aria-label="Listen to sentence">
                                    <SoundIcon />
                                </button>
                            </div>
                        </Card>
                    ))}
                </div>
            </section>

            <section className="mt-8">
                <h3 className="text-2xl font-semibold mb-4 border-b-2 border-green-200 pb-2">קטעי קריאה</h3>
                {unit.readingPassages && unit.readingPassages.length > 0 ? (
                    <div>
                        <div className="mb-4">
                            <label htmlFor="passage-select" className="block text-sm font-medium text-slate-700 mb-1">בחר קטע קריאה:</label>
                            <select 
                                id="passage-select"
                                value={selectedPassageIndex}
                                onChange={(e) => setSelectedPassageIndex(parseInt(e.target.value, 10))}
                                className="w-full md:w-1/2 p-2 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            >
                                {unit.readingPassages.map((p, index) => (
                                    <option key={index} value={index}>{p.title}</option>
                                ))}
                            </select>
                        </div>
                        <FillInTheBlanksPassage passage={unit.readingPassages[selectedPassageIndex]} />
                    </div>
                ) : (
                    <p className="text-slate-500">אין קטעי קריאה ליחידה זו.</p>
                )}
            </section>

             <section className="mt-8">
                <h3 className="text-2xl font-semibold mb-4 border-b-2 border-purple-200 pb-2">משחקים</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <Card onClick={() => onLaunchGame({ type: 'memory', data: unit.games.memory, unitTitle: unit.title, grade })} className="p-6 text-center">
                        <span className="text-4xl">🧠</span>
                        <h4 className="text-xl font-bold mt-2">משחק זיכרון</h4>
                        <p className="text-slate-500 text-sm">מצאו את הזוגות</p>
                    </Card>
                    <Card onClick={() => onLaunchGame({ type: 'matching', data: unit.games.matching, unitTitle: unit.title, grade })} className="p-6 text-center">
                        <span className="text-4xl">🔗</span>
                        <h4 className="text-xl font-bold mt-2">התאמת מילים</h4>
                        <p className="text-slate-500 text-sm">התאימו מילה ופירוש</p>
                    </Card>
                    <Card onClick={() => onLaunchGame({ type: 'spelling', data: unit.games.spelling, unitTitle: unit.title, grade })} className="p-6 text-center">
                         <span className="text-4xl">✍️</span>
                        <h4 className="text-xl font-bold mt-2">איות נכון</h4>
                        <p className="text-slate-500 text-sm">אייתו את המילה</p>
                    </Card>
                     <Card onClick={() => onLaunchGame({ type: 'bingo', data: unit.games.bingo, unitTitle: unit.title, grade })} className="p-6 text-center">
                        <span className="text-4xl">🅱️</span>
                        <h4 className="text-xl font-bold mt-2">בינגו</h4>
                        <p className="text-slate-500 text-sm">סמנו שורה וזכו</p>
                    </Card>
                </div>
            </section>
        </div>
    );
}

const SoundIcon: React.FC = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>;

export default LessonView;