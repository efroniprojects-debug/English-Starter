
import React, { useState, useRef, useCallback } from 'react';
import Button from './ui/Button';
import Card from './ui/Card';
import { getPronunciationFeedback } from '../services/geminiService';

const PronunciationTool: React.FC = () => {
  const [text, setText] = useState('hello world');
  const [isRecording, setIsRecording] = useState(false);
  const [feedback, setFeedback] = useState<{ score: number, feedback: string } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const handleListen = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      const hebrewRegex = /[\u0590-\u05FF]/;
      if (hebrewRegex.test(text)) {
          utterance.lang = 'he-IL';
      }
      window.speechSynthesis.speak(utterance);
    } else {
      alert('מצטערים, הדפדפן שלך לא תומך בהקראת טקסט.');
    }
  };

  const startRecording = useCallback(async () => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        setIsRecording(true);
        setFeedback(null);
        audioChunksRef.current = [];
        mediaRecorderRef.current = new MediaRecorder(stream);
        mediaRecorderRef.current.ondataavailable = (event) => {
          audioChunksRef.current.push(event.data);
        };
        mediaRecorderRef.current.onstop = async () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm;codecs=opus' });
          setIsLoading(true);
          const result = await getPronunciationFeedback(audioBlob, text);
          setFeedback(result);
          setIsLoading(false);
           // Stop all tracks to turn off the microphone indicator
          stream.getTracks().forEach(track => track.stop());
        };
        mediaRecorderRef.current.start();
      } catch (err) {
        console.error('Error accessing microphone:', err);
        alert('לא ניתן לגשת למיקרופון. אנא בדוק/י את ההרשאות.');
      }
    } else {
      alert('מצטערים, הדפדפן שלך אינו תומך בהקלטה.');
    }
  }, [text]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  }, [isRecording]);

  const renderStars = (score: number) => {
    const totalStars = 10;
    const filledStars = Math.round(score);
    return (
        <div className="flex" dir="ltr">
            {[...Array(totalStars)].map((_, i) => (
                <svg key={i} className={`w-6 h-6 ${i < filledStars ? 'text-yellow-400' : 'text-gray-300'}`} fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.368 2.448a1 1 0 00-.364 1.118l1.287 3.957c.3.921-.755 1.688-1.54 1.118l-3.368-2.448a1 1 0 00-1.175 0l-3.368 2.448c-.784.57-1.838-.197-1.539-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.05 9.384c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69L9.049 2.927z" />
                </svg>
            ))}
        </div>
    );
};

  return (
    <section className="max-w-2xl mx-auto text-center">
      <h1 className="text-3xl md:text-4xl font-bold mb-4">כלי לבדיקת הגייה</h1>
      <p className="text-slate-600 mb-8">כתבו מילה או משפט באנגלית, הקשיבו להגייה הנכונה, ואז הקליטו את עצמכם כדי לקבל משוב.</p>
      
      <Card className="p-8">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="w-full p-3 border-2 border-slate-200 rounded-lg text-xl mb-4 focus:ring-2 focus:ring-blue-400 focus:border-blue-400"
          rows={2}
          dir="auto"
        />
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={handleListen} variant="secondary" disabled={!text}>הקשב</Button>
            <Button onClick={isRecording ? stopRecording : startRecording} disabled={!text || isLoading} className="bg-red-500 hover:bg-red-600 focus:ring-red-400 text-white">
                {isRecording ? 'עצור הקלטה' : 'בדוק הגייה'}
            </Button>
        </div>

        {isRecording && <p className="mt-4 text-red-500 animate-pulse">מקליט עכשיו...</p>}
        {isLoading && <p className="mt-4 text-blue-500">מעבד את ההקלטה...</p>}

        {feedback && !isLoading && (
            <div className="mt-8 text-right">
                <h3 className="text-xl font-bold mb-4">המשוב שלך:</h3>
                <Card className="bg-sky-50 p-4">
                    <div className="flex items-center justify-between">
                       <span className="font-semibold">ציון:</span>
                       {renderStars(feedback.score)}
                    </div>
                    <p className="mt-4"><span className="font-semibold">טיפ לשיפור:</span> {feedback.feedback}</p>
                </Card>
            </div>
        )}
      </Card>
    </section>
  );
};

export default PronunciationTool;
