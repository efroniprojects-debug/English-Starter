import React from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import type { Page } from '../App';


interface GamesProps {
    onNavigate: (page: Page) => void;
}

const Games: React.FC<GamesProps> = ({ onNavigate }) => {
    const gameTypes = [
        { name: 'משחק זיכרון', description: 'חידוד הזיכרון על ידי מציאת זוגות תואמים של מילים באנגלית ובעברית. כל שלב מוסיף עוד זוגות ומאתגר יותר!', icon: '🧠', color: 'bg-blue-100 text-blue-600' },
        { name: 'התאמת מילים', description: 'בחנו את אוצר המילים שלכם על ידי התאמה מהירה בין מילה באנגלית לפירוש הנכון שלה בעברית.', icon: '🔗', color: 'bg-green-100 text-green-600' },
        { name: 'איות נכון', description: 'הקשיבו למילה באנגלית ואייתו אותה נכון. דרך מצוינת לשפר את הכתיבה וההקשבה בו זמנית.', icon: '✍️', color: 'bg-amber-100 text-amber-600' },
        { name: 'בינגו', description: 'הקשיבו למילה שמוכרזת וסמנו אותה בלוח שלכם. השלימו שורה, טור או אלכסון כדי לנצח!', icon: '🅱️', color: 'bg-red-100 text-red-600' }
    ];

  return (
    <section>
      <div className="text-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">משחקים לתרגול וכיף</h1>
        <p className="text-slate-600 max-w-2xl mx-auto mb-10">המשחקים שלנו מותאמים אישית לכל יחידת לימוד! כדי לשחק, היכנסו לכיתה וליחידה הרצויה, ושם תמצאו את המשחקים עם אוצר המילים שלמדתם.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {gameTypes.map(game => (
            <Card key={game.name} className="p-6">
                <div className="flex items-start space-i-4">
                    <div className={`flex-shrink-0 h-14 w-14 rounded-lg flex items-center justify-center text-3xl ${game.color}`}>
                        {game.icon}
                    </div>
                    <div>
                        <h2 className="text-xl font-bold">{game.name}</h2>
                        <p className="text-slate-600 mt-1">{game.description}</p>
                    </div>
                </div>
            </Card>
        ))}
      </div>

      <div className="text-center">
        <Button onClick={() => onNavigate('grades')} className="text-lg">
            בחרו כיתה והתחילו לשחק!
        </Button>
      </div>
    </section>
  );
};

export default Games;