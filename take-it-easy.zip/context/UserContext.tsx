
import React, { createContext, useContext, ReactNode } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import type { UserProgress, UserProfile, Avatar } from '../types';

interface UserContextType {
  progress: UserProgress;
  setProgress: (progress: UserProgress) => void;
  profile: UserProfile;
  setProfile: (profile: UserProfile) => void;
  addPoints: (amount: number) => void;
  unlockAvatar: (avatar: Avatar) => boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

const defaultProgress: UserProgress = {
  completedUnits: [],
  learnedWords: [],
  averageScore: 0,
  streak: 0,
  points: 50,
};

const defaultProfile: UserProfile = {
    name: 'Explorer',
    avatarId: 1,
    unlockedAvatars: [1],
};

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [progress, setProgress] = useLocalStorage<UserProgress>('userProgress', defaultProgress);
  const [profile, setProfile] = useLocalStorage<UserProfile>('userProfile', defaultProfile);
  
  const addPoints = (amount: number) => {
    setProgress(prev => ({ ...prev, points: prev.points + amount }));
  };

  const unlockAvatar = (avatar: Avatar): boolean => {
    if (progress.points >= avatar.cost && !profile.unlockedAvatars.includes(avatar.id)) {
      setProgress(prev => ({...prev, points: prev.points - avatar.cost}));
      setProfile(prev => ({...prev, unlockedAvatars: [...prev.unlockedAvatars, avatar.id]}));
      return true;
    }
    return false;
  }

  return (
    <UserContext.Provider value={{ progress, setProgress, profile, setProfile, addPoints, unlockAvatar }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
