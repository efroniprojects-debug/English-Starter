import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";

// Fix: Per Gemini API guidelines, the API key must be sourced from process.env.API_KEY.
const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    throw new Error("API_KEY is not defined in the environment.");
}
const ai = new GoogleGenAI({ apiKey: API_KEY });

const model = "gemini-2.5-flash";

interface PronunciationFeedback {
  score: number;
  feedback: string;
}

// Function to convert a blob to a base64 string
const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        // Result is "data:audio/webm;codecs=opus;base64,..."
        // We only need the part after the comma
        resolve(reader.result.split(',')[1]);
      } else {
        reject(new Error("Failed to read blob as base64 string"));
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};


export const getPronunciationFeedback = async (
  audioBlob: Blob,
  targetWord: string
): Promise<PronunciationFeedback> => {
  try {
    const audioData = await blobToBase64(audioBlob);
    
    const audioPart = {
      inlineData: {
        mimeType: audioBlob.type,
        data: audioData,
      },
    };

    const prompt = `You are an expert English pronunciation coach for young children learning English in Israel. A student is trying to say the word "${targetWord}". Please listen to their audio and provide feedback.
    
    Your response must be in Hebrew and in JSON format only.
    
    The JSON object should have two keys:
    1. "score": A number from 1 (needs a lot of work) to 10 (perfect).
    2. "feedback": A short, simple, and encouraging tip in Hebrew.
    
    Example feedback phrases: "הגייה מצוינת!", "כל הכבוד!", "קרוב מאוד! נסה להדגיש את ההברה הראשונה.", "עבודה טובה! שימ/י לב לצליל הסופי."
    
    Evaluate the audio and return the JSON.`;

    const textPart = { text: prompt };

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: model,
        contents: { parts: [audioPart, textPart] },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.NUMBER },
              feedback: { type: Type.STRING }
            }
          }
        }
    });

    const jsonString = response.text;
    const result = JSON.parse(jsonString);

    if (typeof result.score === 'number' && typeof result.feedback === 'string') {
      return result;
    } else {
      throw new Error("Invalid response format from API");
    }
  } catch (error) {
    console.error("Error getting pronunciation feedback:", error);
    return {
      score: 0,
      feedback: "אוי, הייתה בעיה בבדיקה. נסה שוב!",
    };
  }
};
