
# ABC English Explorer

An interactive platform for Israeli students in grades 1-6 to learn English through lessons, games, and activities. This project is built with React, TypeScript, and Tailwind CSS.

## Project Structure

- **/ (root)**: Contains the main application setup files (`index.html`, `index.tsx`, `App.tsx`).
- **/public/**: Contains static assets that are served directly.
  - **/public/assets/images/**: Images and logos.
  - **/public/lessons/**: JSON files with lesson content for each grade.
  - **/public/games/**: JSON files with data for various games.
- **/components/**: Reusable React components.
  - **/components/ui/**: Generic UI components like buttons and cards.
- **/context/**: React context for global state management.
- **/hooks/**: Custom React hooks, e.g., for interacting with LocalStorage.
- **/services/**: Modules for interacting with external APIs, like the Gemini API.
- **/types.ts**: Global TypeScript type definitions.

## How to Run Locally

This project is set up as a standard React application, likely using a build tool like Vite or Create React App.

1.  **Prerequisites**:
    *   Node.js (v18+)
    *   npm or yarn

2.  **Setup**:
    *   Place all the provided files into a new project directory.
    *   Create a `.env` file in the root of your project and add your Google Gemini API key:
        ```
        VITE_GEMINI_API_KEY=YOUR_API_KEY_HERE
        ```
        *(Note: If not using Vite, the environment variable name might need to be `REACT_APP_GEMINI_API_KEY`)*

3.  **Install Dependencies**:
    *   Open a terminal in the project root and run:
        ```bash
        npm install react react-dom @google/genai
        npm install -D typescript @types/react @types/react-dom tailwindcss autoprefixer postcss
        ```

4.  **Run the Development Server**:
    *   ```bash
        npm run dev 
        ```
        *(This command might vary based on your `package.json` setup. `npm start` is also common.)*
    *   Open your browser and navigate to `http://localhost:5173` (or the address shown in the terminal).

## Browser Requirements for Speech Recognition

The "Check Pronunciation" feature uses the Web Speech API (`SpeechRecognition`), which is currently supported in:
-   Google Chrome (Desktop & Android)
-   Microsoft Edge

The feature may not work in other browsers like Firefox or Safari.

## How to Deploy

You can deploy this application to any static hosting service.

### Deploying to Netlify or Vercel

1.  Connect your GitHub repository to Netlify or Vercel.
2.  Configure the build settings:
    *   **Build Command**: `npm run build`
    *   **Publish Directory**: `dist` (or `build`)
3.  Add your `VITE_GEMINI_API_KEY` as an environment variable in the Netlify/Vercel project settings.
4.  Deploy!

### Deploying to GitHub Pages

1.  Configure your `package.json` for GitHub Pages.
2.  Run the build command: `npm run build`.
3.  Push the contents of the `dist` (or `build`) folder to the `gh-pages` branch of your repository.

---
Created with passion for learning.
