import React, { useState, useCallback } from 'react';
import { UserProvider } from './context/UserContext';
import Header from './components/Header';
import Home from './components/Home';
import Grades from './components/Grades';
import Games from './components/Games';
import PronunciationTool from './components/PronunciationTool';
import Progress from './components/Progress';
import LessonView from './components/LessonView';
import Profile from './components/Profile';
import GamePlayer from './components/GamePlayer';
import type { ActiveGame } from './types';

export type Page = 'home' | 'grades' | 'games' | 'pronunciation' | 'progress' | 'lesson' | 'profile';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedGrade, setSelectedGrade] = useState<number | null>(null);
  const [activeGame, setActiveGame] = useState<ActiveGame | null>(null);

  const navigateTo = useCallback((page: Page) => {
    setCurrentPage(page);
  }, []);

  const handleSelectGrade = useCallback((grade: number) => {
    setSelectedGrade(grade);
    setCurrentPage('lesson');
  }, []);
  
  const handleLaunchGame = useCallback((game: ActiveGame) => {
      setActiveGame(game);
  }, []);

  const handleExitGame = useCallback(() => {
      setActiveGame(null);
  }, []);

  const renderContent = () => {
    if (activeGame) {
        return <GamePlayer game={activeGame} onExit={handleExitGame} />;
    }
    
    switch (currentPage) {
      case 'home':
        return <Home onNavigate={navigateTo} onSelectGrade={handleSelectGrade} />;
      case 'grades':
        return <Grades onSelectGrade={handleSelectGrade} />;
      case 'lesson':
        if (selectedGrade === null) {
            setCurrentPage('grades');
            return <Grades onSelectGrade={handleSelectGrade} />;
        }
        return <LessonView grade={selectedGrade} onLaunchGame={handleLaunchGame} />;
      case 'games':
        return <Games onNavigate={navigateTo} />;
      case 'pronunciation':
        return <PronunciationTool />;
      case 'progress':
        return <Progress />;
      case 'profile':
        return <Profile />;
      default:
        return <Home onNavigate={navigateTo} onSelectGrade={handleSelectGrade} />;
    }
  };

  return (
    <UserProvider>
      <div className="min-h-screen bg-gradient-to-b from-sky-100 to-blue-50 text-slate-800">
        <Header onNavigate={navigateTo} />
        <main className="container mx-auto px-4 py-8">
          {renderContent()}
        </main>
        <footer className="text-center py-4 text-slate-500 text-sm">
          <p>&copy; 2024 Take It Easy. כל הזכויות שמורות.</p>
        </footer>
      </div>
    </UserProvider>
  );
};

export default App;