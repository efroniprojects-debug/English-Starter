export interface ReadingPassageBlank {
  correctAnswer: string;
  options: string[];
}

export interface ReadingPassage {
  title: string;
  passageTemplate: string;
  blanks: ReadingPassageBlank[];
  translation: string;
}

export interface VocabularyItem {
  en: string;
  he: string;
  phon: string;
}

export interface Sentence {
  en: string;
  he: string;
}

// --- Game Types ---

export interface MemoryPair {
  en: string;
  he: string;
}

export interface MemoryLevel {
  level: number;
  pairs: MemoryPair[];
}

export interface MatchingItem {
    term: string;
    definition: string;
}

export interface MatchingLevel {
    level: number;
    title: string;
    items: MatchingItem[];
}

export interface SpellingWord {
    level: number;
    word: string;
    hint: string;
}

export interface BingoLevel {
    level: number;
    title: string;
    words: string[]; // A pool of ~25-30 words for this level's boards
}

export interface UnitGames {
    memory: MemoryLevel[];
    matching: MatchingLevel[];
    spelling: SpellingWord[];
    bingo: BingoLevel[];
}

export interface Unit {
  unit: number;
  title: string;
  vocabulary: VocabularyItem[];
  sentences: Sentence[];
  readingPassages: ReadingPassage[];
  games: UnitGames;
}

export interface GradeData {
  grade: number;
  title: string;
  units: Unit[];
}

export interface UserProgress {
  completedUnits: number[];
  learnedWords: string[];
  averageScore: number;
  streak: number;
  points: number;
}

export interface Avatar {
    id: number;
    name: string;
    image: string;
    cost: number;
}

export interface UserProfile {
    name:string;
    avatarId: number;
    unlockedAvatars: number[];
}

export interface ActiveGame {
    type: 'memory' | 'matching' | 'spelling' | 'bingo';
    data: any;
    unitTitle: string;
    grade: number;
}